keys = {
  'indicoKey': '554a44501bf0ff8f8ba3ac4f47ce4d48',
  'aylientAppId': 'f8199a4c',
  'aylientAppKey': 'e9b87eefc244c51aef4240522769bc5b',
  'googleMapKey': 'AIzaSyAD--KR8TukHG0Ux-o94MCFZHmOTXQhzj4',
  'twitterConsumerKey': '5fuNQd0GJUJ98EFGEtkjvupXS',
  'twitterConsumerSecret': 'Z6BCfw5rx8bAkxxf6DlDqX37tJAgmEgHeXj18yqGOGfMmgi7JV',
  'twitterAccessTokenKey': '405184919-fOP0IguXA73Qpl3ZLHODC6i15tgYufBMJ7vXqWGI',
  'twitterAccessTokenSecret': 'TlFpBGBOkJkWZeMWQNPti5HikOxbgmCBvtmAYCj5gqwz1'
};
module.exports = keys;
